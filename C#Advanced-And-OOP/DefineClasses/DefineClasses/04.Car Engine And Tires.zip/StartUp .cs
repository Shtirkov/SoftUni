﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Car car = new Car();
            car.Make = "VW";
            car.Model = "Golf";
            car.Year = 1992;

            Console.WriteLine($"Make: {car.Make}{Environment.NewLine}Model: {car.Model}{Environment.NewLine}Year: {car.Year}");

            car.FuelQuantity = 200;
            car.FuelConsumption = 200;
            car.Drive(200);
            Console.WriteLine(car.WhoIAm());

            var tires = new Tire[4]
            {
                new Tire(1, 2.5),
                 new Tire(1, 2.5),
                  new Tire(1, 2.5),
                   new Tire(1, 2.5),
        };

            var engine = new Engine(560, 6300);

            var newCar = new Car("Lamborghini", "Urus", 2010, 250, 9, engine, tires);
        }
    }
}
