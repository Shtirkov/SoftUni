﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Shopping_Spree.Common
{
   public static class GlobalConstants
    {
        public const string InvalidNameExceptionMsg = "Name cannot be empty";
        public const string InvalidMoneyExceptionMsg = "Money cannot be negative";
    }
}
