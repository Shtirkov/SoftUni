﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public interface IDrivable
    {
        public string Drive(double distance);
    }
}
