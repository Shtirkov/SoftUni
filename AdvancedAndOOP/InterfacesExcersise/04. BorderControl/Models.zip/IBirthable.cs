﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _05.Bithday_Celebrations
{
   public interface IBirthable
    {
        public string Name { get;}

        public string Birthdate { get;}
    }
}
