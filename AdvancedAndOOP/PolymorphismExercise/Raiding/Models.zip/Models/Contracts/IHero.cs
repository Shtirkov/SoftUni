﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Raiding.Models
{
    public interface IHero
    {
        public string CastAbility();
    }
}
