﻿using _03.Shopping_Spree.Core;
using System;

namespace _03.Shopping_Spree
{
    public class StartUp
    {
       public static void Main(string[] args)
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
